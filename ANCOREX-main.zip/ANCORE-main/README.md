<h1 align="center">
  <img src="https://files.catbox.moe/dmxoe7.jpeg" width="300" /><br>
  <strong>🔥 ANCORE-MD 🔥</strong>
</h1>

<p align="center"><i>The Friendly WhatsApp Bot - Powered by Corex with 💙</i></p>
---

<p align="center">
  <img src="https://files.catbox.moe/ztq2yj.jpeg" height="270" style="border-radius:12px;" />
</p>

---


<p align="center">
  <a href="https://ancore-pair-code.onrender.com/pair">
    <img src="https://img.shields.io/badge/🌐%20Pair%20Session-ANCOREMD-red?style=for-the-badge&logo=whatsapp" />
  </a>
  <a href="https://whatsapp.com/channel/0029Vb6nHar2phHORBFhOn3p">
    <img src="https://img.shields.io/badge/🫂%20WhatsApp%20Channel-Richie-success?style=for-the-badge&logo=whatsapp" />
  </a>
  <a href="https://t.me/corex2410">
    <img src="https://img.shields.io/badge/💙%20Corex24-Telegram-blue?style=for-the-badge&logo=telegram" />
  </a>
</p>
---


 # SET-UP

 # Fork

---

### Deployment Guide

### 1️⃣ Deploy on Koyeb

[Deploy Now](https://ancore-pair-code.onrender.com/) to set up your bot on Koyeb.

### 2️⃣ Deploy on Render

[Deploy Now](render.com) to set up your bot on Render.


---

## 🚀 How to Start
